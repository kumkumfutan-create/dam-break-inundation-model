import type { FloodRecord, RiskLevel } from "./dataset";
import { derivedRisk } from "./risk";

export type Scenario = {
  depth: number;
  velocity: number;
  waterLevel: number;
  arrival: number;
};

export function simulate(record: FloodRecord, scenario: Scenario) {
  const depth = record.flood_depth_m * scenario.depth;
  const velocity = record.water_velocity_mps * scenario.velocity;
  const waterLevel = record.water_level_m * scenario.waterLevel;
  const arrival = Math.max(0.1, record.flood_arrival_time_hr * scenario.arrival);
  const risk: RiskLevel = derivedRisk(record, scenario.depth, scenario.velocity);
  return { depth, velocity, waterLevel, arrival, risk };
}

export function curve(record: FloodRecord, scenario: Scenario, progress = 1) {
  const result = simulate(record, scenario);
  const points = Array.from({ length: 9 }, (_, index) => {
    const phase = index / 8;
    const eased = Math.min(1, Math.max(0, (progress * 1.15 - phase * 0.55) / 0.6));
    return {
      hour: Number((record.flood_arrival_time_hr * phase).toFixed(1)),
      depth: Number((result.depth * (0.15 + eased * 0.85)).toFixed(2)),
      velocity: Number((result.velocity * (0.35 + eased * 0.65)).toFixed(2)),
      level: Number((result.waterLevel * (0.22 + eased * 0.78)).toFixed(2)),
    };
  });
  return points;
}
