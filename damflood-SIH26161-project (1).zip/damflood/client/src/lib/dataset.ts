export const REQUIRED_HEADERS = [
  "location_id",
  "dam_name",
  "state",
  "river",
  "village",
  "latitude",
  "longitude",
  "rainfall_mm",
  "river_discharge_m3s",
  "water_level_m",
  "elevation_m",
  "population_density_per_km2",
  "infrastructure_count",
  "distance_from_dam_km",
  "flood_depth_m",
  "water_velocity_mps",
  "flood_arrival_time_hr",
  "population_at_risk",
  "risk_score",
  "risk_level",
  "safe_zone",
  "evacuation_priority",
  "emergency_action",
] as const;

export type RiskLevel = "Low" | "Medium" | "High" | "Critical";
export type EvacuationPriority = "Immediate" | "High" | "Moderate" | "Low";
export type SafeZone = "Recommended" | "Not Recommended";

export type FloodRecord = {
  location_id: number;
  dam_name: string;
  state: string;
  river: string;
  village: string;
  latitude: number;
  longitude: number;
  rainfall_mm: number;
  river_discharge_m3s: number;
  water_level_m: number;
  elevation_m: number;
  population_density_per_km2: number;
  infrastructure_count: number;
  distance_from_dam_km: number;
  flood_depth_m: number;
  water_velocity_mps: number;
  flood_arrival_time_hr: number;
  population_at_risk: number;
  risk_score: number;
  risk_level: RiskLevel;
  safe_zone: SafeZone;
  evacuation_priority: EvacuationPriority;
  emergency_action: string;
};

export type DatasetError = { row: number; column?: string; message: string };
export type DatasetValidation = {
  headers: string[];
  records: FloodRecord[];
  errors: DatasetError[];
  rowCount: number;
  valid: boolean;
};

const numericFields = new Set<string>([
  "location_id",
  "latitude",
  "longitude",
  "rainfall_mm",
  "river_discharge_m3s",
  "water_level_m",
  "elevation_m",
  "population_density_per_km2",
  "infrastructure_count",
  "distance_from_dam_km",
  "flood_depth_m",
  "water_velocity_mps",
  "flood_arrival_time_hr",
  "population_at_risk",
  "risk_score",
]);

const categorical = {
  risk_level: new Set(["Low", "Medium", "High", "Critical"]),
  safe_zone: new Set(["Recommended", "Not Recommended"]),
  evacuation_priority: new Set(["Immediate", "High", "Moderate", "Low"]),
};

function parseCsvRows(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let quoted = false;
  for (let i = 0; i < text.length; i += 1) {
    const char = text[i];
    const next = text[i + 1];
    if (char === '"') {
      if (quoted && next === '"') {
        field += '"';
        i += 1;
      } else {
        quoted = !quoted;
      }
    } else if (char === "," && !quoted) {
      row.push(field.trim());
      field = "";
    } else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && next === "\n") i += 1;
      row.push(field.trim());
      if (row.some((cell) => cell.length > 0)) rows.push(row);
      row = [];
      field = "";
    } else {
      field += char;
    }
  }
  if (field.length > 0 || row.length > 0) {
    row.push(field.trim());
    if (row.some((cell) => cell.length > 0)) rows.push(row);
  }
  return rows;
}

function asRecord(values: Record<string, string>, row: number, errors: DatasetError[]): FloodRecord | null {
  const output: Record<string, unknown> = {};
  for (const header of REQUIRED_HEADERS) {
    const value = values[header] ?? "";
    if (!value && header !== "infrastructure_count") {
      errors.push({ row, column: header, message: "Value is required." });
      continue;
    }
    if (numericFields.has(header)) {
      const number = Number(value);
      if (!Number.isFinite(number)) {
        errors.push({ row, column: header, message: "Must be a finite number." });
      } else {
        output[header] = number;
      }
    } else {
      output[header] = value;
    }
  }

  const latitude = Number(output.latitude);
  const longitude = Number(output.longitude);
  if (Number.isFinite(latitude) && (latitude < -90 || latitude > 90)) {
    errors.push({ row, column: "latitude", message: "Must be between -90 and 90." });
  }
  if (Number.isFinite(longitude) && (longitude < -180 || longitude > 180)) {
    errors.push({ row, column: "longitude", message: "Must be between -180 and 180." });
  }
  for (const [field, options] of Object.entries(categorical)) {
    const value = output[field];
    if (typeof value === "string" && !options.has(value)) {
      errors.push({ row, column: field, message: `Expected one of ${Array.from(options).join(", ")}.` });
    }
  }
  return errors.some((error) => error.row === row) ? null : (output as FloodRecord);
}

export function validateCsv(text: string, expectedRows = 500): DatasetValidation {
  const rows = parseCsvRows(text);
  const headers = (rows[0] ?? []).map((header) => header.trim());
  const errors: DatasetError[] = [];
  if (headers.length !== REQUIRED_HEADERS.length || headers.some((header, index) => header !== REQUIRED_HEADERS[index])) {
    errors.push({ row: 1, message: `Header must contain exactly the required 23 columns in the supplied order.` });
  }
  const records: FloodRecord[] = [];
  for (let index = 1; index < rows.length; index += 1) {
    const row = rows[index];
    if (row.length !== REQUIRED_HEADERS.length) {
      errors.push({ row: index + 1, message: `Expected ${REQUIRED_HEADERS.length} columns, found ${row.length}.` });
      continue;
    }
    const values = Object.fromEntries(REQUIRED_HEADERS.map((header, column) => [header, row[column] ?? ""]));
    const record = asRecord(values, index + 1, errors);
    if (record) records.push(record);
  }
  if (Math.max(rows.length - 1, 0) !== expectedRows) {
    errors.push({ row: 1, message: `This application is scoped to exactly ${expectedRows} data rows; found ${Math.max(rows.length - 1, 0)}.` });
  }
  return { headers, records, errors, rowCount: Math.max(rows.length - 1, 0), valid: errors.length === 0 && records.length > 0 };
}

export function formatCsvPreview(text: string, rows = 10): string[][] {
  return parseCsvRows(text).slice(0, rows + 1);
}

export function summarize(records: FloodRecord[]) {
  const sum = (key: keyof FloodRecord) => records.reduce((total, record) => total + Number(record[key] ?? 0), 0);
  const max = (key: keyof FloodRecord) => records.reduce((current, record) => Math.max(current, Number(record[key] ?? 0)), 0);
  const min = (key: keyof FloodRecord) => records.reduce((current, record) => Math.min(current, Number(record[key] ?? 0)), Number.POSITIVE_INFINITY);
  const countBy = <T extends string>(key: keyof FloodRecord, values: readonly T[]) =>
    Object.fromEntries(values.map((value) => [value, records.filter((record) => record[key] === value).length])) as Record<T, number>;
  const riskCounts = countBy("risk_level", ["Low", "Medium", "High", "Critical"] as const);
  const evacuationCounts = countBy("evacuation_priority", ["Immediate", "High", "Moderate", "Low"] as const);
  return {
    affectedAreas: new Set(records.filter((record) => record.flood_depth_m > 0).map((record) => `${record.location_id}-${record.village}`)).size,
    populationAtRisk: sum("population_at_risk"),
    criticalHigh: records.filter((record) => record.risk_level === "Critical" || record.risk_level === "High").length,
    maxDepth: max("flood_depth_m"),
    maxVelocity: max("water_velocity_mps"),
    earliestArrival: records.length ? min("flood_arrival_time_hr") : 0,
    latestArrival: records.length ? max("flood_arrival_time_hr") : 0,
    infrastructure: sum("infrastructure_count"),
    recommendedSafeZones: records.filter((record) => record.safe_zone === "Recommended").length,
    rainfallAverage: records.length ? sum("rainfall_mm") / records.length : 0,
    dischargeAverage: records.length ? sum("river_discharge_m3s") / records.length : 0,
    riskCounts,
    evacuationCounts,
  };
}

export type Filters = {
  search: string;
  state: string;
  river: string;
  dam: string;
  risk: string;
  priority: string;
  safeZone: string;
};

export const emptyFilters: Filters = { search: "", state: "All states", river: "All rivers", dam: "All dams", risk: "All risks", priority: "All priorities", safeZone: "All safe-zone flags" };

export function applyFilters(records: FloodRecord[], filters: Filters) {
  const query = filters.search.trim().toLowerCase();
  return records.filter((record) => {
    const searchable = `${record.village} ${record.state} ${record.river} ${record.dam_name}`.toLowerCase();
    return (!query || searchable.includes(query))
      && (filters.state === "All states" || record.state === filters.state)
      && (filters.river === "All rivers" || record.river === filters.river)
      && (filters.dam === "All dams" || record.dam_name === filters.dam)
      && (filters.risk === "All risks" || record.risk_level === filters.risk)
      && (filters.priority === "All priorities" || record.evacuation_priority === filters.priority)
      && (filters.safeZone === "All safe-zone flags" || record.safe_zone === filters.safeZone);
  });
}

export const uniqueValues = (records: FloodRecord[], key: keyof FloodRecord) => Array.from(new Set(records.map((record) => String(record[key])))).sort();
