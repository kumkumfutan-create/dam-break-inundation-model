import type { FloodRecord } from "./dataset";

export type ReportSections = {
  summary: boolean;
  simulation: boolean;
  risk: boolean;
  exposure: boolean;
  recommendations: boolean;
};

export type ReportContext = {
  filteredCount?: number;
  filters?: string;
  topLocations?: FloodRecord[];
};

const defaultSections: ReportSections = { summary: true, simulation: true, risk: true, exposure: true, recommendations: true };

export function buildReportHtml(title: string, record: FloodRecord, summary: Record<string, string | number>, riskBullets: string[], scenario: Record<string, string | number>, sections: ReportSections = defaultSections, context: ReportContext = {}) {
  const list = (items: string[]) => items.map((item) => `<li>${item}</li>`).join("");
  const summarySection = sections.summary ? `<h2>Dashboard summary</h2><div class="grid">${Object.entries(summary).map(([key, value]) => `<div class="metric"><span>${key}</span><b>${value}</b></div>`).join("")}</div><p class="meta">Active filtered locations: ${context.filteredCount ?? "—"}${context.filters ? ` · Filters: ${context.filters}` : ""}</p>` : "";
  const simulationSection = sections.simulation ? `<h2>DEMO/SIMULATION scenario</h2><p>${Object.entries(scenario).map(([key, value]) => `${key}: <strong>${value}</strong>`).join(" · ")}</p>` : "";
  const riskSection = sections.risk ? `<h2>Risk analysis</h2><p><span class="tag">${record.risk_level} risk</span> Dataset risk score: ${record.risk_score.toFixed(3)}</p><ul>${list(riskBullets)}</ul>` : "";
  const exposureSection = sections.exposure ? `<h2>Population, infrastructure & affected area</h2><table><tr><th>Metric</th><th>Value</th></tr><tr><td>Population at risk</td><td>${Math.round(record.population_at_risk).toLocaleString()}</td></tr><tr><td>Infrastructure assets</td><td>${record.infrastructure_count}</td></tr><tr><td>Flood depth</td><td>${record.flood_depth_m.toFixed(2)} m</td></tr><tr><td>Water velocity</td><td>${record.water_velocity_mps.toFixed(2)} m/s</td></tr><tr><td>Water level</td><td>${record.water_level_m.toFixed(2)} m</td></tr><tr><td>Elevation</td><td>${record.elevation_m.toFixed(1)} m</td></tr><tr><td>Arrival time</td><td>${record.flood_arrival_time_hr.toFixed(1)} hr</td></tr></table>${context.topLocations?.length ? `<h3>Top filtered locations</h3><table><tr><th>Location</th><th>Risk</th><th>Depth</th><th>Population</th></tr>${context.topLocations.map((location) => `<tr><td>${location.village}</td><td>${location.risk_level}</td><td>${location.flood_depth_m.toFixed(2)} m</td><td>${Math.round(location.population_at_risk).toLocaleString()}</td></tr>`).join("")}</table>` : ""}` : "";
  const recommendationsSection = sections.recommendations ? `<h2>Safe zone & evacuation</h2><p>Safe zone flag: <strong>${record.safe_zone}</strong><br>Evacuation priority: <strong>${record.evacuation_priority}</strong><br>Emergency action: ${record.emergency_action}</p>` : "";
  return `<!doctype html><html><head><meta charset="utf-8"><title>${title}</title><style>
  body{font-family:Arial,sans-serif;color:#14213d;margin:32px;line-height:1.45}h1{color:#0b1630;margin-bottom:4px}h2{border-bottom:2px solid #dbeafe;padding-bottom:6px;margin-top:26px}h3{margin-top:20px}.meta{color:#64748b;font-size:12px}.banner{background:#e0f2fe;border:1px solid #38bdf8;padding:12px;border-radius:8px;font-weight:bold}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.metric{background:#f8fafc;border:1px solid #e2e8f0;padding:12px;border-radius:8px}.metric b{display:block;font-size:20px;color:#0b1630}.tag{display:inline-block;background:#fee2e2;color:#991b1b;border-radius:999px;padding:4px 9px;font-weight:bold;font-size:12px}li{margin:6px 0}table{border-collapse:collapse;width:100%;margin-top:8px}td,th{border:1px solid #e2e8f0;padding:8px;text-align:left}@media print{body{margin:18px}.banner{break-inside:avoid}}
  </style></head><body><h1>${title}</h1><div class="meta">SIH26161 · Dam Break Inundation Modelling · ${new Date().toLocaleString()}</div><p class="banner">DEMO/SIMULATION DATA — These values are derived from the uploaded CSV and deterministic demonstration calculations. They are not real HEC-RAS results.</p>
  <h2>Selected location</h2><p><strong>${record.village}</strong> · ${record.dam_name} · ${record.river} · ${record.state}<br>Coordinates: ${record.latitude.toFixed(5)}, ${record.longitude.toFixed(5)}</p>${summarySection}${simulationSection}${riskSection}${exposureSection}${recommendationsSection}<p class="meta">Generated from the active in-memory dataset. No external data or live hydrodynamic model was used.</p></body></html>`;
}

export function downloadReport(html: string, filename: string) {
  const blob = new Blob([html], { type: "text/html;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename.replace(/[^a-z0-9._-]/gi, "-");
  link.click();
  URL.revokeObjectURL(url);
}
