import type { FloodRecord, RiskLevel } from "./dataset";

const rank: Record<RiskLevel, number> = { Low: 1, Medium: 2, High: 3, Critical: 4 };

export function riskExplanation(record: FloodRecord) {
  const drivers = [
    { label: "Flood depth", value: `${record.flood_depth_m.toFixed(2)} m`, score: record.flood_depth_m },
    { label: "Water velocity", value: `${record.water_velocity_mps.toFixed(2)} m/s`, score: record.water_velocity_mps },
    { label: "Population at risk", value: `${Math.round(record.population_at_risk).toLocaleString()}`, score: record.population_at_risk / 300 },
    { label: "Infrastructure exposure", value: `${record.infrastructure_count} assets`, score: record.infrastructure_count / 10 },
    { label: "Arrival time", value: `${record.flood_arrival_time_hr.toFixed(1)} hr`, score: 12 / Math.max(record.flood_arrival_time_hr, 0.2) },
  ].sort((a, b) => b.score - a.score);
  const explanation = [
    `${record.risk_level} risk is inherited from the dataset risk level with a risk score of ${record.risk_score.toFixed(3)}.`,
    `${record.village} is modelled with ${record.flood_depth_m.toFixed(2)} m flood depth and ${record.water_velocity_mps.toFixed(2)} m/s water velocity.`,
    `${Math.round(record.population_at_risk).toLocaleString()} people and ${record.infrastructure_count} infrastructure assets are flagged in this record.`,
    record.flood_arrival_time_hr <= 4 ? `The ${record.flood_arrival_time_hr.toFixed(1)} hr arrival time leaves a short response window.` : `The ${record.flood_arrival_time_hr.toFixed(1)} hr arrival time provides the response window recorded in the dataset.`,
    record.safe_zone === "Recommended" ? "The dataset marks this location as a recommended safe zone." : "The dataset marks this location as not recommended as a safe zone.",
  ];
  return { drivers: drivers.slice(0, 4), explanation };
}

export function derivedRisk(record: FloodRecord, depthMultiplier = 1, velocityMultiplier = 1): RiskLevel {
  const score = record.risk_score * 0.55 + Math.min(record.flood_depth_m * depthMultiplier / 5, 1) * 0.25 + Math.min(record.water_velocity_mps * velocityMultiplier / 4, 1) * 0.2;
  if (record.risk_level === "Critical" || score >= 0.72) return "Critical";
  if (record.risk_level === "High" || score >= 0.58) return "High";
  if (record.risk_level === "Medium" || score >= 0.42) return "Medium";
  return "Low";
}

export const priorityDescription: Record<string, string> = {
  Immediate: "Initiate immediate evacuation and move vulnerable populations first.",
  High: "Prepare transport and issue a high-priority evacuation notice.",
  Moderate: "Stage resources and monitor the arrival window for escalation.",
  Low: "Maintain awareness and keep the local response plan ready.",
};

export function compareRisk(a: FloodRecord, b: FloodRecord) {
  return rank[b.risk_level] - rank[a.risk_level] || b.population_at_risk - a.population_at_risk;
}
